from typing import Any

from tno.mpc.communication import SupportsSerialization, Serialization
from bitarray import bitarray
from bitarray.util import serialize, deserialize


class SerializableBitarray(SupportsSerialization, bitarray):

    def __init__(self, *args, **kwargs):
        super(SerializableBitarray, self).__init__(*args, **kwargs)

    def serialize(self, **kwargs: Any) -> bytes:
        return serialize(self)

    @staticmethod
    def deserialize(obj: bytes, **kwargs: Any) -> "SerializableBitarray":
        return SerializableBitarray(deserialize(obj))

# Load the serialization logic into the communication module
if "SerializableBitarray" not in Serialization.custom_deserialization_funcs:
    Serialization.set_serialization_logic(SerializableBitarray, check_annotations=False)