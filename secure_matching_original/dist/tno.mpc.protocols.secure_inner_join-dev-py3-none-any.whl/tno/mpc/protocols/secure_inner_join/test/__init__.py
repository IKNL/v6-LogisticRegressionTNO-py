"""
Testing module of the tno.mpc.protocols.secure_inner_join library
"""
